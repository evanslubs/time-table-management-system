/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timeman;

import java.sql.*;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
//import sun.util.logging.PlatformLogger;

/**
 *
 * @author User 
 */
public class MyQuery {
    
    public Connection getConnection(){
        Connection con = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");

            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mtms","root","");
         
        }catch(SQLException ex){
        Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE,null,ex);} catch (ClassNotFoundException ex) {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    } 
    
    
    public HashMap<String, Integer> populateCombo(){
      HashMap<String, Integer>map=new HashMap<>();
      Connection con = getConnection();
      Statement st;
      ResultSet rs;
      
        try {
            st=con.createStatement();
            rs=st.executeQuery("SELECT * FROM `course`");
            comboItem cmi;
            
            while(rs.next()){
            cmi=new comboItem(rs.getInt(1),rs.getString(2));
            map.put(cmi.getCatName(), cmi.getCatId());
            }
        } catch (SQLException ex) {
            Logger.getLogger(MyQuery.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
       return map;
    }
}

