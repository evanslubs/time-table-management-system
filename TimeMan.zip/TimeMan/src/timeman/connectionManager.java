/*
 * Copyright (C) 2018 emulindwa
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package timeman;

import java.sql.*;
//Connection  con=DriverManager.getConnection("jdbc:mysql://sql2.freemysqlhosting.net:3306/sql2225620","sql2225620","sS4*iF2*");
//Connection con=DriverManager.getConnection("jdbc:mysql://afrowave.ddns.net:3306/mtms","root","mOtherb0ard");
/**
 *
 * @author evans
 */
public class connectionManager {
                
    private static String url = "jdbc:mysql://localhost:3306/mtms";    
    private static String driverName = "com.mysql.jdbc.Driver";   
    private static String username = "root";   
    private static String password = "";
    private static Connection con;
    private static String urlstring;
    
    /*private static String url = "sql2.freemysqlhosting.net:3306/sql2225620";    
    private static String driverName = "com.mysql.jdbc.Driver";   
    private static String username = "sql2225620";   
    private static String password = "sS4*iF2*";
    private static Connection con;
    private static String urlstring;*/
    
        
    /*private static String driverName = "com.mysql.jdbc.Driver";
    private static Connection con;
    private static String url = "afrowave.ddns.net:3306/mtms";
    private static String username = "root";   
    private static String password = "mOtherb0ard";
    private static String urlstring;*/

    public static Connection getConnection() {
        try {
            Class.forName(driverName);
            try {
                con = DriverManager.getConnection(url, username, password);
                //con=DriverManager.getConnection("jdbc:mysql://sql2.freemysqlhosting.net:3306/sql2225620","sql2225620","sS4*iF2*");
                //con=DriverManager.getConnection("jdbc:mysql://afrowave.ddns.net:3306/mtms","root","mOtherb0ard");
                //con=DriverManager.getConnection("jdbc:mysql://host01.afrowave.ltd/mtms","c1aps1","mOtherb0ard");
            } catch (SQLException ex) {
                // log an exception. fro example:
                System.out.println("Failed to create the database connection."); 
            }
        } catch (ClassNotFoundException ex) {
            // log an exception. for example:
            System.out.println("Driver not found."); 
        }
        return con;
    }
}
